﻿namespace ConfigurationLibrary.Classes
{
    public enum ConnectionsConfiguration
    {
        Development,
        Stage,
        Production
    }
}